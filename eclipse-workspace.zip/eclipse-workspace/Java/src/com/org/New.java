package com.org;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class New extends CreateEmployee {
	public static void main(String[] args) {
		/*Scanner sc=new Scanner(System.in);
	
		
		

		System.out.println("enter the emp id");
		int empId=sc.nextInt();


	
		
		

		List<New> emp = new ArrayList<New>();
		
		
		New e1 = new New();
		New e2 = new New();
		New e3 = new New();
		New e4 = new New();
		New e5 = new New();
		
		if(empId==01)
		{
		e1.setId(01);
		e1.setName("ranjitha");
		e1.setEmailId("ranjitha123@gmail.com");
		e1.setDesignation("business analyst");
		e1.setempNumber(98765432);
		emp.add(e1);
		}
		
		else if(empId==02)
		{
		
		e2.setId(02);
		e2.setName("selvam");
		e2.setEmailId("selvam123@gmail.com");
		e2.setDesignation("manager");
		e2.setempNumber(76532789);
		emp.add(e2);
		
		}
		else if(empId==03)
		{

		e3.setId(03);
		e3.setName("indira");
		e3.setEmailId("indira123@gmail.com");
		e3.setDesignation("software developer");
		e3.setempNumber(76532789);
		emp.add(e3);
		}
		else if(empId==04)
		{
		e4.setId(04);
		e4.setName("ajith");
		e4.setEmailId("ajith@gmail.com");
		e4.setDesignation("software tester");
		e4.setempNumber(876543677);
		emp.add(e4);
		}
		else if(empId==05)
		{
			
		
		e5.setId(05);
		e5.setName("saravanan");
		e5.setEmailId("saravanan123@gmail.com");
		e5.setDesignation("HR manager");
		e5.setempNumber(765432456);
		emp.add(e5);
		}

		
		for (New x : emp) {

			System.out.println("id :"+x.getId());

			System.out.println("name :"+x.getName());
			System.out.println("emailid :"+x.getEmailId());
			System.out.println("designation :"+x.getDesignation());
			System.out.println("empnumber :"+x.getempNumber());

		}
	
	}
	
	}*/
