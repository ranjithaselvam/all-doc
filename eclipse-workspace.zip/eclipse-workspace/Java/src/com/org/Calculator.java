package com.org;

import java.lang.String;
import java.lang.System;
import java.util.Scanner;

public class Calculator {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s="";
		do 
		{
		System.out.println("enter the first number");
		
		double a=sc.nextDouble();
		System.out.println("enter the second element");
		double b=sc.nextDouble();
		
		System.out.println("enter your choice\n +\n -\n *\n /" );
		char c=sc.next().charAt(0);

		double output;
		switch(c)
		{
		case '+':
			output=a+b;
			break;
		case '-':
			output=a-b;
			break;
		case '*':
			output=a*b;
			break;
		case '/':
			output=a/b;
			break;
			default :
				System.out.println("entered wrong");
				return;
				
		}
		
		System.out.println(a+" "+c+" "+b+"="+output);
		System.out.println("continue(y/n)");
		s=sc.next();
		}while(s.equals("y"));
	}
	

}
