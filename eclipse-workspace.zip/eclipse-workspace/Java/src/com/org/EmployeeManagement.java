package com.org;

import java.util.Scanner;

public class EmployeeManagement {
	public static void main(String[] args) {
		EmployeeDetails ed=new EmployeeDetails();
		Scanner sc = new Scanner(System.in);
		String userName="ranjitha";
		String password="ranjitha.selvam";
		System.out.println("login page");
		System.out.println("enter the user name :");
		userName = sc.nextLine();
		System.out.println("enter the password :");

		password = sc.nextLine();
		if (userName.equals("ranjitha")&&password.equals("ranjitha.selvam")) {
			System.out.println("login successfully");
		}
		else
		{
			System.out.println("please try again");
		}
		System.out.println("MENU DRIVEN");
		System.out.println("***************");
		System.out.println("1-create employee");
		System.out.println("2-fetch employee");
		System.out.println("3-employee details");
		System.out.println("4-delete");
		System.out.println("enter your choice");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			ed.createEmployee();
			
			break;
		//case 2:
			//ed.fetching();
			//break;
			
		}

	}

}
