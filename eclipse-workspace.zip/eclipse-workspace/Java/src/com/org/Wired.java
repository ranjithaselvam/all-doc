package com.org;

import java.lang.String;
import java.lang.System;
import java.util.Scanner;

public class Wired {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	if(n%2==1)
	{
		System.out.println("wired");
	}
	else
	{
		if(n>2&&n<6)
		{
			System.out.println("not wired");
		}
		else if(n>7&&n<20)
		{
			System.out.println("wired");
		}
		else
		{
			System.out.println("wired");
		}
	}
	sc.close();

}
}
