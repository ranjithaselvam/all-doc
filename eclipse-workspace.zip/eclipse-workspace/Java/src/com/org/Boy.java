package com.org;

import java.lang.String;
import java.lang.System;

public class Boy extends Girl{
	public static void disp()
	{
		System.out.println("hi");
		
	}
	public static void main(String[] args) {
		Girl b=  new Boy();
		
		b.disp();
		
		
	}

}
