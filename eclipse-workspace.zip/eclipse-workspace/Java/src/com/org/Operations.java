package com.org;

import java.util.Scanner;

public class Operations {
	public void fibonacci()
	{
		int userInput1 = 0, userInput2 = 1, add;
		Scanner sc = new Scanner(System.in);
		String s = "";
		do {
			System.out.println("enter the number");
			int n = sc.nextInt();
			System.out.println(userInput1);
			System.out.println(userInput2);
			for (int i = 0; i < n; i++) {
				add= userInput1+ userInput2;
				System.out.println(add);
				userInput1 = userInput2;
				userInput2= add;
			}
			System.out.println("continue(y/n)");
			s = sc.next();

		} while (s.equals("y"));

	}
	public void factorial()
	{
		String s = "";
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("enter the number");
			int input = sc.nextInt();
			int fact = 1;
			for (int i = 1; i <= input; i++) {
				fact = fact * i;
			}
			System.out.println(fact);
			System.out.println("continue(y/n)");
			s = sc.next();
		} while (s.equals("y"));
		
	
	}
public void Prime()
{
	
	String s="";
	Scanner sc = new Scanner(System.in);
	do
	{
		int count=0;
	System.out.println("enter the number");
	int input=sc.nextInt();
	while(count!=2)
	{	
	input++;
	count=0;
	for(int i=1;i<=input;i++)
	{
		if(input%i==0)
		{
			count++;
		}
	}
			if(count==2)
			{
				System.out.println(input);
				
			}s=sc.next();
	}
			System.out.println("continue(y/n)");
			
	}while(s.equals("y"));	
}
}
