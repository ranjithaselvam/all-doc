package com.org;

import java.lang.System;

public class Girl {
	 public  static void disp() {
		 System.out.println("hello");
	 }

}
