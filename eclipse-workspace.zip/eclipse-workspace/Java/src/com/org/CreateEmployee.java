package com.org;

public class CreateEmployee {
	/*private String name;
	private String emailId;
	private String designation;
	private int empNumber; 
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public int getempNumber() {
		return empNumber;
	}
	public void setempNumber(int empNumber) {
		this.empNumber = empNumber;
	}
	
	
	

}
*/