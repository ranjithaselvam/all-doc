package com.org;

import java.util.Scanner;

public class Operation {
	  
		 double fnum, snum, ans;

	    public void addition(double fnum,double snum){
	        ans = fnum + snum;
	        System.out.println(ans);
	    }

	    public void subtraction(double fnum,double snum){
	        ans = fnum - snum;
	        System.out.println(ans);
	    }

	    public void division(double fnum,double snum){
	        ans = fnum / snum;
	        System.out.println(ans);
	    }

	    public void multiplication(double fnum,double snum){
	        ans = fnum * snum;
	        System.out.println(ans);
	    }
	
	
      

	    



	}
	


