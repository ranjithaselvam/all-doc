package com.org;

import java.lang.String;
import java.lang.System;

public class SumClass implements SumInterface{

	    public int mymethod(int num1, int num2){
	           int op= num1+num2;
	           return op;
	    }
	    public static void main(String args[])
	    {
	           SumClass obj= new SumClass();
	           System.out.println(obj.mymethod(2, 3));
	    }
	}


