package com.org;

import java.util.Scanner;

public class Fibonacci {
	public static void main(String[] args) {
		int a = 0, b = 1, c;
		Scanner sc = new Scanner(System.in);
		String s = "";
		do {
			System.out.println("enter the number");
			int n = sc.nextInt();
			System.out.println(a);
			System.out.println(b);
			for (int i = 0; i < n; i++) {
				c = a + b;
				System.out.println(c);
				a = b;
				b = c;
			}
			System.out.println("continue(y/n)");
			s = sc.next();

		} while (s.equals("y"));
	}
}
