package com.org;

import java.lang.String;
import java.lang.System;

public class Complex {
	int real,img;
	public Complex(int r,int i)
	{
		this.real=r;
		this.img=i;
		
	}
	public static Complex sum(Complex c1,Complex c2)
	{
		Complex temp=new Complex(0,0);
		temp.real=c1.real+c2.real;
		temp.img=c1.img+c2.img;
		return temp;
	}
	public static void main(String[] args) {
		Complex c1=new Complex(5,6);
		Complex c2=new Complex(3,6);
		Complex temp=sum(c1,c2);
		System.out.println(temp.real+"+"+temp.img+"i");
	}


	
	    }
	


