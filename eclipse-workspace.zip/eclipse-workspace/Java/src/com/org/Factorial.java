package com.org;

import java.util.Scanner;

public class Factorial {
	public static void main(String[] args) {

		String s = "";
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("enter the number");
			int input = sc.nextInt();
			int fact = 1;
			for (int i = 1; i <= input; i++) {
				fact = fact * i;
			}
			System.out.println(fact);
			System.out.println("continue(y/n)");
			s = sc.next();
		} while (s.equals("y"));
	}
}
