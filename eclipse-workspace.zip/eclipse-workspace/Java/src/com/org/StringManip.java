package com.org;

import java.lang.String;
import java.lang.System;
import java.util.Scanner;

public class StringManip {
	//public static void main(String[] args) {
		/*int count=0;
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		for(int i=0;i<s.length();i++)
		{
			char c=s.charAt(i);
			if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
			{
				System.out.println(c+"vowles");
				count++;
			}
			else
			{
				System.out.println(c+"consonant");
				count++;
			}
		}*/
		
	
	 private static String str = "BeginnersBook";

	   //Static class
	   static class MyNestedClass{
		//non-static method
		public void disp() {

		   
		   System.out.println(str); 
		}

	   }
	   public static void main(String args[])
	   {
	       
		StringManip.MyNestedClass obj = new StringManip.MyNestedClass();
		obj.disp();
	   }
	}


