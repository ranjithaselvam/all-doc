package com.org;

import java.util.Scanner;

public class MenuDriven {
	public static void main(String[] args) {
	String s="";	
	int userChoice;
	Operations os=new Operations();
	do
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
	System.out.println(" Select Operation to Perform:");
    System.out.println("1-Fibonacci");
    System.out.println("2-Factorial");
    System.out.println("3-Prime");
    
    userChoice = sc.nextInt();
    switch(userChoice)
    {
    case 1:
    	os.fibonacci();
    	break;
    case 2:
    	os.factorial();
    	break;
    case 3:
    	os.Prime();
    	break;
    } 
	}while(true);
	
	}
}
