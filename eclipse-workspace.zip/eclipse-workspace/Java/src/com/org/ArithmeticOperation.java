package com.org;

import java.util.Scanner;

public class ArithmeticOperation {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
				
		int a[]=new int[8];
		System.out.println("enter the element:");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		int i=0;
		int sum=0;int sub=0;
		while(i<a.length)
		{
			if(i==0)
			{
				sum=a[i]+a[i+1];
				System.out.println(sum);
						
			}
			if(i==2)
			{
				sub=a[i]-a[i+1];
				System.out.println(sub);
				sum+=sub;
			}
			if(i==4)
			{
				sub=a[i]*a[i+1];
				System.out.println(sub);
				sum+=sub;
			}
			if(i==6)
			{
				sub=a[i]/a[i+1];
				System.out.println(sub);
				sum+=sub;
			}
			i++;
			
		}
		
		System.out.println(sum);
		
		
	}

}
